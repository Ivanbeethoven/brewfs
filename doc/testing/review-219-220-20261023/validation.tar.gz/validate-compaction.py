"""Serial compaction regression and relevant gates; no unrelated build waits."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert Path.cwd().name == 'brewfs-fix-compaction-review'
regression = ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
              '--test', 'compactor_test', '--', '--test-threads=1', '--nocapture']
commands = [
    *[(f'after-{n}', regression) for n in (1, 2, 3)],
    ('fmt', ['cargo', 'fmt', '--all', '--check']),
    ('check-overlay', ['cargo', 'check', '--workspace', '--features', 'workspace-overlay']),
    ('clippy-overlay', ['cargo', 'clippy', '--workspace', '--all-targets', '--features',
                        'workspace-overlay', '--', '-D', 'warnings']),
    ('focused-default', ['cargo', 'test', '--workspace', '--lib', '--bins',
                         'chunk::slice::', '--', '--test-threads=1']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--lib', '--bins',
                         '--', '--test-threads=1']),
    ('overlay-resolver', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
                         '--test', 'workspace_overlay_resolver', '--', '--test-threads=1']),
    ('check-workspace', ['cargo', 'check', '--workspace']),
    ('build-workspace', ['cargo', 'build', '--workspace']),
    ('check-tokio', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-tokio-runtime']),
    ('check-uring', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-io-uring-runtime']),
    ('clippy-default', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    *[(f'syntax-{name}', ['bash', '-n', f'docker/compose-xfstests/{name}.sh'])
      for name in ('run_perf_in_container', 'run_redis_perf',
                   'run_juicefs_perf_in_container', 'run_juicefs_perf')],
    *[(name, ['bash', f'docker/compose-xfstests/{name}.sh']) for name in (
        'test_perf_report_delta', 'test_juicefs_direct_matrix', 'test_juicefs_perf_report')],
    ('diff-check', ['git', 'diff', '--check']),
]
if len(sys.argv) > 1:
    commands = commands[next(i for i, (name, _) in enumerate(commands)
                              if name == sys.argv[1]):]
for name, command in commands:
    result = subprocess.run([sys.executable, str(root / 'run.py'),
                             '219-220-' + name, *command])
    if result.returncode:
        raise SystemExit(result.returncode)
