# Compaction regressions #219 and #220

These bugs are verified on unmodified production code at `origin/main`
`a8459dc92142bf94224e4f4af903f592cef5cb13`. The combined baseline command is
recorded in `219-220-242-before.log`; its historical label does not imply
ownership of issue #242. The relevant three regressions actually ran and
failed; eight other compactor cases passed.

## #219: deleting a committed object after a lost reply

Heavy compaction first records the pending slice and uploads its objects, then
publishes the replacement through `replace_slices_for_compact_with_version`.
The generic metadata-error branch calls `cleanup_uncommitted_slice` even if
the error describes a lost reply after successful publication. That cleanup
physically deletes the replacement's objects, now referenced by live metadata.

The fault-injection test delegates to the real SQLite replacement, then returns
`ConnectionReset`. It verifies that publication happened and reads the new
object. Before the fix:

```text
heavy_compaction_keeps_published_objects_after_a_lost_commit_reply ... FAILED
lost reply cleanup deleted an already-published object:
Err(incomplete block read for slice 1 block 0: requested 4096 bytes at offset 0, received 0)
```

The candidate preserves uploaded objects and the pending record on an uncertain
publication error. Known version conflicts still use immediate cleanup. It
returns the original error; it does not manufacture a success receipt.

## #220: allocation IDs used as publication order

Readers resolve the authoritative metadata vector from its last entry backward.
Slice IDs are allocated before upload and do not define publication order.
Light compaction sorts IDs in descending order when choosing covered slices;
heavy compaction sorts them ascending before overwriting the output. Both can
therefore resurrect an older write with a larger ID, even with successful CAS.

The regressions publish a high-ID older write and a low-ID later overwrite,
then compare reads across each compaction mode. Before the fix:

```text
heavy_compaction_preserves_publication_order_with_nonmonotonic_ids ... FAILED
heavy compaction resurrected the older, higher-ID data
light_compaction_preserves_publication_order_with_nonmonotonic_ids ... FAILED
light compaction resurrected the older, higher-ID data
test result: FAILED. 8 passed; 3 failed
```

The candidate iterates the metadata vector in reverse for coverage and retains
survivors in their original relative order. Heavy compaction merges in the
same forward publication order as the authoritative vector. Version checks,
delayed deletion and conservative whole-slice coverage rules remain in place.

Both production candidates were prepared only after those failures were
captured. After-tests and acceptance gates remain pending. No PR yet.
