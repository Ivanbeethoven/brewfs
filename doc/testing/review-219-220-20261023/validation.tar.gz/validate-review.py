"""Run one branch's regressions and acceptance gates, strictly serially."""
import pathlib
import os
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
issue = sys.argv[1]
targets, focused = {
    '213': (['entity_fragment_reads'], 'workspace_overlay::entity::'),
    '219-220': (['compactor_test'], 'chunk::slice::'),
    '221-241': (['packed_index_cache', 'packed_index_hot_lookup'],
                'workspace_overlay::packed_v3::'),
    '222': (['workspace_session_drop'], 'workspace_overlay::lifecycle::'),
}[issue]
regression = ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay']
for target in targets:
    regression += ['--test', target]
regression += ['--', '--test-threads=1', '--nocapture']
commands = [
    *[(f'after-{n}', regression) for n in (1, 2, 3)],
    ('focused', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
                 '--lib', focused, '--', '--test-threads=1']),
    ('fmt', ['cargo', 'fmt', '--all', '--check']),
    *[(f'syntax-{name}', ['bash', '-n', f'docker/compose-xfstests/{name}.sh'])
      for name in ('run_perf_in_container', 'run_redis_perf',
                   'run_juicefs_perf_in_container', 'run_juicefs_perf')],
    *[(name, ['bash', f'docker/compose-xfstests/{name}.sh']) for name in (
        'test_perf_report_delta', 'test_juicefs_direct_matrix', 'test_juicefs_perf_report')],
    ('check-overlay', ['cargo', 'check', '--workspace', '--features', 'workspace-overlay']),
    ('clippy-overlay', ['cargo', 'clippy', '--workspace', '--all-targets', '--features',
                        'workspace-overlay', '--', '-D', 'warnings']),
    ('overlay-unit-suite', ['cargo', 'test', '--workspace', '--lib', '--bins',
                           '--features', 'workspace-overlay', '--', '--test-threads=1']),
    ('overlay-resolver', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
                         '--test', 'workspace_overlay_resolver', '--', '--test-threads=1']),
    ('check-workspace', ['cargo', 'check', '--workspace']),
    ('build-workspace', ['cargo', 'build', '--workspace']),
    ('check-tokio', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-tokio-runtime']),
    ('check-uring', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-io-uring-runtime']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--lib', '--bins',
                         '--', '--test-threads=1']),
    ('clippy-default', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('diff-check', ['git', 'diff', '--check']),
]
if issue == '213':
    position = next(i for i, (suffix, _) in enumerate(commands) if suffix == 'overlay-resolver')
    commands.insert(position, ('focused-serial', [
        'cargo', 'test', '--workspace', '--lib', '--bins', '--features', 'workspace-overlay',
        'workspace_overlay::entity::', '--', '--test-threads=1']))
if len(sys.argv) > 2:
    start = next(i for i, (suffix, _) in enumerate(commands) if suffix == sys.argv[2])
    commands = commands[start:]
for suffix, command in commands:
    if suffix == 'overlay-unit-suite' and os.environ.get('REVIEW_DEFER_OVERLAY_UNIT') == '1':
        print(f'{issue}: full overlay unit gate deferred after two 24 GiB compiler OOMs; NOT passed', flush=True)
        continue
    environment = os.environ.copy()
    if suffix in ('focused', 'focused-serial', 'overlay-unit-suite'):
        environment['RUSTC_WRAPPER'] = str(root / 'rustc-low-memory.py')
    if command[:2] == ['cargo', 'test'] and '--lib' in command:
        command = ['cargo', '--config', 'profile.test.package.brewfs.codegen-units=256',
                   *command[1:]]
    name = f'{issue}-{suffix}'
    if suffix == 'overlay-unit-suite' and os.environ.get('REVIEW_OVERLAY_RETRY_LABEL'):
        name += '-' + os.environ['REVIEW_OVERLAY_RETRY_LABEL']
    elif (root / (name + '.log')).exists() and os.environ.get('REVIEW_GATE_RETRY_LABEL'):
        name += '-' + os.environ['REVIEW_GATE_RETRY_LABEL']
    if (root / (name + '.log')).exists():
        raise SystemExit(f'{name} already exists: inspect before resuming with a new label')
    result = subprocess.run([sys.executable, str(root / 'run.py'), name, *command], env=environment)
    if result.returncode:
        raise SystemExit(result.returncode)
