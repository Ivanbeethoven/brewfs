"""Export completed evidence without implying that pending gates passed."""
import json
from pathlib import Path
import re
import shlex
import sys
import tarfile

root = Path(__file__).resolve().parent
issue, destination = sys.argv[1:]
destination = Path(destination)
before = {
    '213': ['213-237-before'],
    '219-220': ['219-220-242-before'],
    '221-241': ['221-before', '241-before'],
    '222': ['222-before'],
}[issue]
records = [json.loads(line) for line in (root / 'runs.jsonl').read_text().splitlines()]
selected = [r for r in records if r['name'] in before or r['name'].startswith(issue + '-')]
by_name = {r['name']: r for r in selected}
for name in before:
    assert by_name[name]['exit_code'] == 101, name
    assert 'test result: FAILED.' in (root / (name + '.log')).read_text(), name
for iteration in (1, 2, 3):
    name = f'{issue}-after-{iteration}'
    assert by_name[name]['exit_code'] == 0, name
    assert 'test result: ok.' in (root / (name + '.log')).read_text(), name

lines = ['# Completed validation commands', '',
         'Only completed commands are listed. See README.md for pending gates and scope.', '',
         'Full output, exact revisions, environments and source patches are in',
         '`validation.tar.gz`. Ignored tests did not run.', '']
for r in selected:
    name = r['name']
    log = (root / (name + '.log')).read_text()
    counts = re.findall(r'test result: (?:ok|FAILED)\. .*', log)
    command = ' '.join(f'{k}={shlex.quote(v)}' for k, v in r['env'].items())
    lines += [f'## {name}', '',
              f"Exit: **{r['exit_code']}**. Worktree: `{r['cwd']}`.", '',
              '```bash', command + ' ' + shlex.join(r['command']), '```', '']
    if counts:
        lines += ['```text', *counts, '```', '']
destination.mkdir(parents=True, exist_ok=True)
(destination / 'commands.md').write_text('\n'.join(lines))
with tarfile.open(destination / 'validation.tar.gz', 'w:gz') as archive:
    for r in selected:
        for extension in ('.log', '.patch', '.rustc-wrapper.py'):
            path = root / (r['name'] + extension)
            if path.exists():
                archive.add(path, arcname=path.name)
    for name in ('run.py', 'validate-compaction.py', 'validate-review.py',
                 'export-completed-evidence.py'):
        path = root / name
        if path.exists():
            archive.add(path, arcname=name)
print(json.dumps({'issue': issue, 'completed_commands': len(selected),
                  'exit_codes': {r['name']: r['exit_code'] for r in selected}}, indent=2))
