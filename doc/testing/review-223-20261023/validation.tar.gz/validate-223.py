"""Serial issue-223 validation, preserving exact commands and complete logs."""
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
commands = [
    *[(f'223-after-{n}', ['cargo', 'test', '-p', 'brewfs', '--lib',
                         'chunk::bandwidth::tests::one_mib_', '--', '--test-threads=1', '--nocapture'])
      for n in (1, 2, 3)],
    ('223-focused', ['cargo', 'test', '-p', 'brewfs', '--lib', 'chunk::bandwidth::', '--', '--test-threads=1']),
    ('223-fmt', ['cargo', 'fmt', '--all', '--check']),
    *[(f'223-syntax-{name}', ['bash', '-n', f'docker/compose-xfstests/{name}.sh']) for name in (
        'run_perf_in_container', 'run_redis_perf', 'run_juicefs_perf_in_container', 'run_juicefs_perf')],
    *[(f'223-{name}', ['bash', f'docker/compose-xfstests/{name}.sh']) for name in (
        'test_perf_report_delta', 'test_juicefs_direct_matrix', 'test_juicefs_perf_report')],
    ('223-check-overlay', ['cargo', 'check', '--workspace', '--features', 'workspace-overlay']),
    ('223-clippy-overlay', ['cargo', 'clippy', '--workspace', '--all-targets', '--features', 'workspace-overlay', '--', '-D', 'warnings']),
    ('223-check-workspace', ['cargo', 'check', '--workspace']),
    ('223-build-workspace', ['cargo', 'build', '--workspace']),
    ('223-check-tokio', ['cargo', 'check', '-p', 'brewfs', '--no-default-features', '--features', 'fuse-tokio-runtime']),
    ('223-check-uring', ['cargo', 'check', '-p', 'brewfs', '--no-default-features', '--features', 'fuse-io-uring-runtime']),
    ('223-workspace-tests', ['cargo', 'test', '--workspace', '--lib', '--bins', '--', '--test-threads=1']),
    ('223-clippy-default', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings']),
    ('223-overlay-resolver', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay', '--test', 'workspace_overlay_resolver', '--', '--test-threads=1']),
    ('223-diff-check', ['git', 'diff', '--check']),
]
for name, command in commands:
    result = subprocess.run([sys.executable, str(root / 'run.py'), name, *command])
    if result.returncode:
        raise SystemExit(result.returncode)
