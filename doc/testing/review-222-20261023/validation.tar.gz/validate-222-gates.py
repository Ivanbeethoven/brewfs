"""Serial #222 gates, after the three public-API regressions succeeded."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
candidate = root.parent / 'brewfs-fix-lease-drop-review'
harness = root.parent / 'brewfs-lease-lifecycle-harness'
assert Path.cwd() == candidate
records = {r['name']: r for r in
           (json.loads(line) for line in (root / 'runs.jsonl').read_text().splitlines())}
for iteration in (1, 2, 3):
    assert records[f'222-after-{iteration}']['exit_code'] == 0
for key, value in {
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_DEV_CODEGEN_UNITS': '16',
    'CARGO_PROFILE_TEST_CODEGEN_UNITS': '16',
    'GIT_OPTIONAL_LOCKS': '0',
    'REVIEW_EXCLUSIVE_HOST': '1',
}.items():
    os.environ[key] = value
os.environ['CARGO_TARGET_DIR'] = str(candidate / 'target')
commands = [
    ('focused-lifecycle', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
                           '--lib', 'workspace_overlay::lifecycle::',
                           '--', '--test-threads=1'], harness),
    ('fmt', ['cargo', 'fmt', '--all', '--check'], candidate),
    ('check-overlay', ['cargo', 'check', '--workspace', '--features', 'workspace-overlay'], candidate),
    ('clippy-overlay', ['cargo', 'clippy', '--workspace', '--all-targets', '--features',
                        'workspace-overlay', '--', '-D', 'warnings'], candidate),
    ('overlay-resolver', ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
                         '--test', 'workspace_overlay_resolver', '--', '--test-threads=1'], candidate),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--lib', '--bins',
                         '--', '--test-threads=1'], candidate),
    ('check-workspace', ['cargo', 'check', '--workspace'], candidate),
    ('build-workspace', ['cargo', 'build', '--workspace'], candidate),
    ('check-tokio', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-tokio-runtime'], candidate),
    ('check-uring', ['cargo', 'check', '-p', 'brewfs', '--no-default-features',
                     '--features', 'fuse-io-uring-runtime'], candidate),
    ('clippy-default', ['cargo', 'clippy', '--workspace', '--all-targets', '--', '-D', 'warnings'], candidate),
    *[(f'syntax-{name}', ['bash', '-n', f'docker/compose-xfstests/{name}.sh'], candidate)
      for name in ('run_perf_in_container', 'run_redis_perf',
                   'run_juicefs_perf_in_container', 'run_juicefs_perf')],
    *[(name, ['bash', f'docker/compose-xfstests/{name}.sh'], candidate) for name in (
        'test_perf_report_delta', 'test_juicefs_direct_matrix', 'test_juicefs_perf_report')],
    ('diff-check', ['git', 'diff', '--check'], candidate),
]
if len(sys.argv) > 1:
    commands = commands[next(i for i, (name, _, _) in enumerate(commands)
                              if name == sys.argv[1]):]
for name, command, cwd in commands:
    result = subprocess.run([sys.executable, str(root / 'run.py'), '222-' + name, *command], cwd=cwd)
    if result.returncode:
        raise SystemExit(result.returncode)
