"""Harness only: exclude unrelated test functions, retaining their helpers.

Run on a disposable worktree containing the test-only patch. This does not
change any production function body. Never apply this transform to a PR branch.
"""
import json
import hashlib
import pathlib
import re
import sys

root = pathlib.Path.cwd()
assert root.name == 'brewfs-lease-lifecycle-harness'
mode = 'lifecycle'
keep = {
    'upper_object_read_uses_bounded_get_without_metadata_head',
    'upper_object_read_rejects_missing_short_corrupt_and_extended_payloads',
    'readdirplus_reuses_attributes_captured_by_opendir',
    'readdirplus_captures_actual_parent_attributes',
    'clean_fuse_release_avoids_metadata_barrier_but_explicit_fsync_keeps_it',
    'packed_file_churn_preserves_unrelated_path_cache',
    'packed_hot_inode_memo_coalesces_concurrent_misses',
    'packed_cold_inode_memo_coalesces_concurrent_misses',
    'packed_reverse_alias_memo_coalesces_concurrent_page_walks',
    'packed_inode_memo_keeps_absence_cached_and_errors_retryable',
    'packed_inode_memo_cancellation_does_not_block_other_keys_or_retry',
    'packed_directory_slow_page_does_not_block_other_offsets',
    'packed_create_reuses_fresh_parent_permission_snapshot',
}
pattern = re.compile(r'(?m)^([ \t]*)#\[((?:tokio::|async_std::)?test(?:\([^\]]*\))?)\][ \t]*$')
source_root = root.parent / 'brewfs-fix-lease-drop-review'
def selected_source(relative):
    if mode == 'lifecycle':
        return relative.startswith('src/workspace_overlay/lifecycle/')
    if mode == 'entity':
        return relative.startswith('src/workspace_overlay/entity/') or relative.endswith('/entity_lower_tests.rs')
    if mode == 'packed':
        return relative.startswith('src/workspace_overlay/meta_layer/') or relative.endswith(tuple(
            '/' + name for name in ('native_effective_export_tests.rs', 'packed_merged_permission_tests.rs',
                                    'packed_raw_bytes_tests.rs', 'native_payload_budget_tests.rs',
                                    'packed_enumeration_tests.rs', 'performance_tests.rs')))
    return False
if mode != 'regressions':
    keep = set()
    for path in (source_root / 'src').rglob('*.rs'):
        if selected_source(str(path.relative_to(source_root))):
            source = path.read_text()
            for match in pattern.finditer(source):
                keep.add(re.search(r'\bfn\s+(\w+)', source[match.end():match.end() + 1500]).group(1))
found = set()
changed = {}
required_modules = {
    ('src/workspace_overlay/entity/data.rs', 'tests'),
    ('src/workspace_overlay/entity/resolver.rs', 'test_support'),
    ('src/workspace_overlay/entity/mod.rs', 'test_objects'),
    ('src/workspace_overlay/meta_layer/mod.rs', 'tests'),
    ('src/workspace_overlay/stores/mod.rs', 'binding_tests'),
    ('src/workspace_overlay/stores/kv_store/packed_reader_pins.rs', 'packed_reader_pin_tests'),
    ('src/workspace_overlay/stores/kv_store.rs', 'topology_test_support'),
    ('src/workspace_overlay/stores/kv_store.rs', 'tests'),
    ('src/workspace_overlay/stores/tikv.rs', 'tests'),
}
child_modules = {
    'src/workspace_overlay/meta_layer/tests.rs': {'packed_lower_tests'},
    'src/workspace_overlay/meta_layer/tests/packed_lower_tests.rs': {'performance_tests'},
    'src/workspace_overlay/stores/binding_tests.rs': set(),
    'src/workspace_overlay/stores/kv_store/packed_reader_pins/packed_reader_pin_tests.rs': {'native_effective_export_tests'},
    'src/workspace_overlay/stores/kv_store/packed_reader_pins/native_effective_export_tests.rs': {'performance_tests'},
}
if mode == 'entity':
    required_modules.discard(('src/workspace_overlay/meta_layer/mod.rs', 'tests'))
    child_modules['src/workspace_overlay/stores/kv_store/packed_reader_pins/packed_reader_pin_tests.rs'] = {'entity_lower_tests'}
elif mode == 'packed':
    required_modules.discard(('src/workspace_overlay/entity/data.rs', 'tests'))
    required_modules.add(('src/workspace_overlay/mod.rs', 'test_base_fixture'))
    child_modules.pop('src/workspace_overlay/meta_layer/tests.rs')
    child_modules.pop('src/workspace_overlay/meta_layer/tests/packed_lower_tests.rs')
    child_modules.pop('src/workspace_overlay/stores/kv_store/packed_reader_pins/native_effective_export_tests.rs')
module_pattern = re.compile(r'(?P<config>#\[cfg\((?:test|all\(test,[^\]]*)\)\])(?P<attrs>\s*(?:#\[[^\]]*\]\s*)*)(?P<decl>(?:pub(?:\([^)]*\))?\s+)?mod\s+(?P<name>\w+))')
for path in sorted((root / 'src').rglob('*.rs')):
    source = (source_root / path.relative_to(root)).read_text()
    relative = str(path.relative_to(root))
    count = 0
    def select(match):
        global count
        following = source[match.end():match.end() + 1500]
        function = re.search(r'\bfn\s+(\w+)', following)
        name = function.group(1) if function else None
        if name in keep and (mode == 'regressions' or selected_source(relative)):
            found.add(name)
            return match.group(0)
        count += 1
        return f'{match.group(1)}#[cfg(any())] // harness-original: #[{match.group(2)}]'
    output = pattern.sub(select, source)
    def select_module(match):
        if (relative, match.group('name')) in required_modules or selected_source(relative):
            return match.group(0)
        return match.group(0).replace(match.group('config'), '#[cfg(any())] // harness-module-original: ' + match.group('config'), 1)
    output = module_pattern.sub(select_module, output)
    if relative in child_modules:
        output = re.sub(r'(?m)^(mod (\w+);)$',
            lambda match: match.group(0) if match.group(2) in child_modules[relative]
            else '#[cfg(any())] // harness-excluded-child\n' + match.group(0), output)
    if relative == 'src/workspace_overlay/stores/kv_store.rs':
        output = re.sub(r'(?m)^(    mod (?:packed_unstarted_recovery|g13_gc_candidates|g13_real_backend_candidates|g10_control_open_growth_candidates) \{)$',
            r'    #[cfg(any())] // harness-excluded-child\n\1', output)
    if output != source:
        changed[str(path.relative_to(root))] = count
    path.write_text(output)
assert found == keep, keep - found
report = {'registered_regressions': sorted(found),
          'mode': mode,
          'demoted_test_attributes': sum(changed.values()), 'files': changed,
          'purpose': 'compile selected tests against unchanged production bodies; not a full suite gate'}
pathlib.Path('/mnt/brewfs-data/src/brewfs-review-evidence-20261023/222-lifecycle-harness-selection.json').write_text(
    json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'files'}))

# Verify the generated harness, including every production function body.
# Restoring only excluded test/module attributes must reproduce the candidate
# source byte for byte. No exclusions belong in the PR branch.
checked = []
for path in sorted((root / 'src').rglob('*.rs')):
    relative = path.relative_to(root)
    source = (source_root / relative).read_text()
    restored = re.sub(
        r'(?m)#\[cfg\(any\(\)\)\] // harness-original: (#\[(?:tokio::|async_std::)?test(?:\([^\]]*\))?\])',
        r'\1', path.read_text())
    restored = re.sub(r'(?m)#\[cfg\(any\(\)\)\] // harness-module-original: (#[^\n]+)', r'\1', restored)
    restored = re.sub(r'(?m)^[ \t]*#\[cfg\(any\(\)\)\] // harness-excluded-child\n', '', restored)
    assert restored == source, str(relative)
    checked.append({'path': str(relative), 'sha256': hashlib.sha256(source.encode()).hexdigest()})
pathlib.Path('/mnt/brewfs-data/src/brewfs-review-evidence-20261023/222-lifecycle-production-equivalence.json').write_text(
    json.dumps({'verified': True, 'selected_tests': len(found), 'files': checked,
                'scope': 'Selected lifecycle tests only; not the full overlay suite.'}, indent=2) + '\n')
print(f'Verified {len(checked)} source files; {len(found)} lifecycle tests selected.')
