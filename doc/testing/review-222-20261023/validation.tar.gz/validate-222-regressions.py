"""Run the saved #222 regression three times with conservative code generation."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert Path.cwd().name == 'brewfs-fix-lease-drop-review'
for key, value in {
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_PROFILE_DEV_CODEGEN_UNITS': '16',
    'CARGO_PROFILE_TEST_CODEGEN_UNITS': '16',
    'GIT_OPTIONAL_LOCKS': '0',
}.items():
    os.environ[key] = value
os.environ.setdefault('CARGO_TARGET_DIR', str(Path.cwd() / 'target'))
record = json.loads((root / '222-before.log').read_text().splitlines()[-1])
assert record['exit_code'] == 101
assert 'dropped mount kept renewing its exclusive writer lease: Some(Busy)' in (root / '222-before.log').read_text()
command = ['cargo', 'test', '-p', 'brewfs', '--features', 'workspace-overlay',
           '--test', 'workspace_session_drop', '--', '--test-threads=1', '--nocapture']
for iteration in (1, 2, 3):
    result = subprocess.run([sys.executable, str(root / 'run.py'),
                             f'222-after-{iteration}', *command])
    if result.returncode:
        raise SystemExit(result.returncode)
