#!/usr/bin/env python3
"""Serialize code generation for the large BrewFS overlay unit test binary."""
import os
import sys

compiler, *arguments = sys.argv[1:]
is_brewfs = '--crate-name' in arguments and arguments[arguments.index('--crate-name') + 1] == 'brewfs'
is_overlay = any('feature="workspace-overlay"' == arg for arg in arguments)
if is_brewfs and is_overlay and '--test' in arguments:
    # These options change compiler scheduling and discarded LLVM names only.
    # They leave test selection, assertions, overflow checks and optimization
    # unchanged. Keep the external 24 GiB memory/zero-swap cap in force.
    os.environ['RUSTC_BOOTSTRAP'] = '1'
    arguments += ['-Zunstable-options', '--jobs-backend=1', '-Zfewer-names=yes', '-Ztime-passes=yes']
    print('Overlay unit compile: serial LLVM backend, fewer IR names; tests unchanged.', flush=True)
os.execv(compiler, [compiler, *arguments])
