#!/usr/bin/env python3
"""Preserve exact commands and output; never overwrite earlier evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

# Evidence collection and build.rs both inspect Git status. Avoid optional
# index refreshes: build.rs watches the index, so a read-only status refresh
# can otherwise force another full build on the next regression invocation.
os.environ.setdefault('GIT_OPTIONAL_LOCKS', '0')

name, *command = sys.argv[1:]
read_only_gate = (command[:2] in (['cargo', 'fmt'], ['git', 'diff'], ['bash', '-n']))
root = Path(__file__).resolve().parent
path = root / (name + '.log')
if path.exists():
    raise SystemExit(f'refusing to overwrite {path}')
def build_pids():
    found = subprocess.run(['pgrep', '-x', 'cargo|rustc'], capture_output=True, text=True)
    active = []
    for pid in found.stdout.split():
        try:
            args = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        except FileNotFoundError:
            continue
        # Version/metadata probes do not build or test anything. Do not abort
        # a compilation when another task merely asks rustc for its version.
        if b'--crate-name' in args or any(
                command in args[1:] for command in
                (b'build', b'check', b'test', b'clippy', b'run', b'bench', b'rustc')):
            active.append(int(pid))
    return active

def is_descendant(pid, ancestor):
    """Include runner children that use setsid for their own cleanup."""
    visited = set()
    while pid > 1 and pid not in visited:
        if pid == ancestor:
            return True
        visited.add(pid)
        try:
            fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            pid = int(fields[1])
        except FileNotFoundError:
            return False
    return False

if not read_only_gate and build_pids():
    raise SystemExit('Another cargo command is active; refusing overlapping build/test.')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
patch = subprocess.check_output(['git', 'diff', '--binary'])
for filename in subprocess.check_output(
        ['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0'):
    if filename:
        patch += subprocess.run(['git', 'diff', '--no-index', '--', '/dev/null',
                                 os.fsdecode(filename)], stdout=subprocess.PIPE).stdout
(root / (name + '.patch')).write_bytes(patch)
record = dict(name=name, command=command, cwd=os.getcwd(), revision=revision,
              patch_sha256=hashlib.sha256(patch).hexdigest(),
              started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              cgroup=Path('/proc/self/cgroup').read_text().strip(),
              env={k: os.environ[k] for k in (
                  'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
                  'CARGO_PROFILE_TEST_DEBUG', 'CARGO_TARGET_DIR',
                  'GIT_OPTIONAL_LOCKS', 'RUSTC_WRAPPER', 'RUSTC_BOOTSTRAP',
                  'ENTITY_DATA_ARTIFACT_ROOT', 'PATH') if k in os.environ})
start = time.monotonic()
if wrapper := os.environ.get('RUSTC_WRAPPER'):
    wrapper_bytes = Path(wrapper).read_bytes()
    (root / (name + '.rustc-wrapper.py')).write_bytes(wrapper_bytes)
    record['rustc_wrapper_sha256'] = hashlib.sha256(wrapper_bytes).hexdigest()
with path.open('w') as log:
    log.write(json.dumps(record) + '\n')
    log.flush()
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    while True:
        try:
            status = process.wait(timeout=2)
            break
        except subprocess.TimeoutExpired:
            if read_only_gate:
                continue
            foreign = []
            for pid in build_pids():
                try:
                    if os.getpgid(pid) != process.pid and not is_descendant(pid, process.pid):
                        foreign.append(pid)
                except ProcessLookupError:
                    pass
            if foreign:
                record['interrupted_for_external_build'] = foreign
                record['external_commands'] = []
                for pid in foreign:
                    try:
                        record['external_commands'].append(
                            Path(f'/proc/{pid}/cmdline').read_bytes()
                            .replace(b'\0', b' ').decode())
                    except FileNotFoundError:
                        pass
                log.write('\nExternal build appeared; interrupting only our process group.\n')
                log.flush()
                os.killpg(process.pid, signal.SIGINT)
                status = process.wait()
                break
    record.update(exit_code=status, seconds=round(time.monotonic() - start, 2))
    log.write('\n' + json.dumps(record) + '\n')
with (root / 'runs.jsonl').open('a') as index:
    index.write(json.dumps(record) + '\n')
print(json.dumps(record), flush=True)
print('\n'.join(path.read_text().splitlines()[-25:]), flush=True)
sys.exit(status if status >= 0 else 128 - status)
