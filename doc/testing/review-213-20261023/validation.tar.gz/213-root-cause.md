# Issue #213: repeated object reads for surviving fragments

Baseline: `a8459dc92142bf94224e4f4af903f592cef5cb13` (`origin/main`
when the isolated worktree was created). Candidate branch:
`codex/fix-entity-read-review-20261023`.

`ChunkMap::replace` preserves the prefix and suffix of an overwritten slice.
`EntityData::read_attempt` deduplicates object descriptors, but its transport
loop calls `read_object` separately for each surviving span. `read_object`
fetches and authenticates the whole immutable object. Consequently a 1 MiB
write followed by a 4 KiB middle overwrite downloads the original 1 MiB
object twice when reading back the file.

The public-API regression writes that shape through `EntityData`, verifies
every returned byte, and counts bounded object GETs and transferred bytes.
The baseline production code is unchanged in the recorded before patch;
that patch contains only regression tests. The before and after regression
sources differ only by rustfmt removing a trailing blank line.

Before (`213-237-before.log`; the historical label exercises only #213):

```text
fragmented read: 3 GETs, 2101248 bytes
assertion `left == right` failed: the surviving prefix and suffix refetched the same object
  left: 3
 right: 2
test result: FAILED. 0 passed; 1 failed
```

After (`213-after-1.log`, `213-after-2.log`, `213-after-3.log`):

```text
fragmented read: 2 GETs, 1052672 bytes
test result: ok. 1 passed; 0 failed
```

The minimal production change groups bounded scatter recipes by immutable
slice ID. It authenticates each distinct object once, copies all requested
fragments, then releases that buffer before fetching the next object. It
preserves descriptor/ownership validation, the before/after transport read
fences, the read-admission lifetime, zero-filled holes, lower-range reads,
and the existing fragmentation bound. It introduces no cross-request cache.

These counts prove removal of redundant transport and hashing for the
reported shape. They are not mounted throughput or latency measurements.
No README performance comparison is changed.

Formatting, overlay workspace check, strict all-target overlay Clippy, and
the seven recorded shell gates have passed. Full overlay/focused and remaining
workspace gates are still pending; two earlier full library test compilations
hit the 24 GiB process-scope cap. An obsolete compiler-option attempt is also
preserved separately. The current retry serializes LLVM code generation and
omits LLVM IR names; test selection and assertions are unchanged. No commit
or PR is authorized by incomplete gates.
